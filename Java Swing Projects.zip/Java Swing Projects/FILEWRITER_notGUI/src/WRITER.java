import java.io.FileWriter;
import java.io.IOException;

public class WRITER {

    public static void main(String[] args) {

        try {
            FileWriter writer = new FileWriter("poem.txt"); // Creates the file write, and assigned he file that its creating a  name
            writer.write("Roses are red \n Violets are blue \n Howdy bby \n yea");      // This will write into our file
            writer.append("\n(A poem by Braeden)");     // This will write (append) at the END of our file always
            writer.close();     // Closes the writer (needed)
        } catch (IOException ignored) {}


    }
}
