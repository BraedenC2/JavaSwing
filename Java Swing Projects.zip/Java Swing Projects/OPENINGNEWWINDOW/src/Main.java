import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class Main {

    public static void main(String[] args) {

        // - - - - - - - - - - Setup - - - - - - - - - - \\

        JFrame frame = new JFrame("1st Window");

        JButton button = new JButton("New Window");

        // - - - - - - - - - - Button - - - - - - - - - - \\

        button.setSize(50,50);
        button.setHorizontalAlignment(JButton.CENTER);
        button.setFocusable(false);
        button.addActionListener(e -> {
            if (e.getSource() == button) {
                frame.dispose();
                NewWindow window = new NewWindow();
            }
        });


        // - - - - - - - - - - Frames - - - - - - - - - - \\

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.add(button);
        frame.setLayout(new FlowLayout());

        frame.setVisible(true);

    }

}
