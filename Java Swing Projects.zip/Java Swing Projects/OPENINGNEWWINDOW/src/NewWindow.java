import javax.swing.*;
import java.awt.*;

public class NewWindow {

    // - - - - - - - - - - Setup - - - - - - - - - - \\

    JFrame frame = new JFrame();
    JLabel label = new JLabel("Hello, New Window here!");

    public NewWindow() {

        // - - - - - - - - - - Labels - - - - - - - - - - \\

        label.setBounds(0,0,500,50);
        label.setFont(new Font("Arial", Font.BOLD, 25));
        label.setHorizontalAlignment(JLabel.CENTER);

        // - - - - - - - - - - Frames - - - - - - - - - - \\

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLayout(new FlowLayout());

        frame.add(label);

        frame.setVisible(true);

    }
}
