import javax.swing.*;
import java.awt.*;

public class Main {

    /* JComboBox:
    A component that combines a button or editable field and a drop-down list
     */

    public static void main(String[] args) {

        // - - - - - - - - - - Setup - - - - - - - - - - \\
        String[] animals = {" ", "Dog", "Cat", "Birb"};
        // If you wanted to use something besides Strings, you have to use the wrapper classes:
        // Integer[], Double[], etc/

        JFrame frame = new JFrame();

        JComboBox comboBox = new JComboBox(animals);


        // - - - - - - - - - - XXXXX - - - - - - - - - - \\

        comboBox.addActionListener(e -> {
            System.out.println(comboBox.getSelectedItem());     // Prints the name
            System.out.println(comboBox.getSelectedIndex());    // Prints the index number
        });

        comboBox.setEditable(true);     // Allows user to "search"
        System.out.println(comboBox.getItemCount());    // This tells you how many items there are
        comboBox.addItem("horse");  // Adds to the array
        comboBox.insertItemAt("Pig", 0);    // adds to an index
        comboBox.setSelectedIndex(0);   // Starts the selection at the index number
        comboBox.removeItem("birb");  // Removes an item from the array
        comboBox.removeItemAt(0); // Removes item at an index
        comboBox.removeAllItems();  // This removes every item

        // - - - - - - - - - - Frames - - - - - - - - - - \\

        frame.add(comboBox);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());
        frame.pack();
        frame.setVisible(true);
    }

}
