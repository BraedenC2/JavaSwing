import javax.swing.*;
import java.awt.*;

public class Main {

    public static void main(String[] args) {

        // JPanels functions as a container to hold other components

        JFrame frame = new JFrame();
        JPanel panel1 = new JPanel();
        JPanel panel2 = new JPanel();
        JPanel panel3 = new JPanel();
        JLabel label = new JLabel();
        ImageIcon icon = new ImageIcon("ShrekLogo.png");

        label.setText("Hi");
        label.setIcon(icon);
        label.setVerticalAlignment(JLabel.BOTTOM);
        label.setHorizontalAlignment(JLabel.RIGHT);
        label.setVerticalTextPosition(JLabel.TOP);
        label.setHorizontalTextPosition(JLabel.CENTER);


        panel1.setBackground(Color.BLACK);  // Sets background
        panel1.setBounds(0, 0, 250, 250);   // Sets bounds

        panel2.setBackground(Color.BLUE);  // Sets background
        panel2.setBounds(250, 0, 250, 250);   // Sets bounds

        panel3.setBackground(Color.GRAY);
        panel3.setBounds(0,250,500,250);
        panel3.setLayout(new BorderLayout());
        panel3.add(label);



        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        frame.setSize(750, 750);
        frame.add(panel1);
        frame.add(panel2);
        frame.add(panel3);

        frame.setVisible(true);

    }

}
