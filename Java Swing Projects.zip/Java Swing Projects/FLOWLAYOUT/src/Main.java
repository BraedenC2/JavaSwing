import javax.swing.*;
import java.awt.*;

public class Main {

    public static void main(String[] args) {

        // Layout Manager defines the natural layout for components within a container

        /* FlowLayout :
        Places components in a row, sized at their preferred size. If the horizontal space in
        the container is too small, the FlowLayout class uses the next available row
         */

        // - - - - - - - - - - Setup - - - - - - - - - - \\

        JFrame frame = new JFrame();
        JButton button1 = new JButton("1");
        JButton button2 = new JButton("2");
        JButton button3 = new JButton("3");
        JButton button4 = new JButton("4");
        JButton button5 = new JButton("5");
        JButton button6 = new JButton("6");
        JButton button7 = new JButton("7");
        JButton button8 = new JButton("8");
        JButton button9 = new JButton("9");
        JLabel label = new JLabel();
        JPanel panel = new JPanel();

        // - - - - - - - - - - Labels - - - - - - - - - - \\

        label.setSize(10, 10);
        label.setBounds(100,100, 100, 100);

        // - - - - - - - - - - Buttons - - - - - - - - - - \\

        button1.addActionListener(e -> {
            label.setText("1");
        });

        button2.addActionListener(e -> {
            label.setText("2");
        });

        button3.addActionListener(e -> {
            label.setText("3");
        });

        button4.addActionListener(e -> {
            label.setText("4");
        });

        button5.addActionListener(e -> {
            label.setText("5");
        });

        button6.addActionListener(e -> {
            label.setText("6");
        });

        button7.addActionListener(e -> {
            label.setText("7");
        });

        button8.addActionListener(e -> {
            label.setText("8");
        });

        button9.addActionListener(e -> {
            label.setText("9");
        });

        // - - - - - - - - - - Panels - - - - - - - - - - \\

        panel.setPreferredSize(new Dimension(100, 250));
        panel.setBackground(Color.LIGHT_GRAY);
        panel.setLayout(new FlowLayout(FlowLayout.CENTER));

        panel.add(button1);
        panel.add(button2);
        panel.add(button3);
        panel.add(button4);
        panel.add(button5);
        panel.add(button6);
        panel.add(button7);
        panel.add(button8);
        panel.add(button9);

        // - - - - - - - - - - Frames - - - - - - - - - - \\

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 0));
        frame.add(panel);
        frame.add(label);
        frame.setVisible(true);

    }

}
