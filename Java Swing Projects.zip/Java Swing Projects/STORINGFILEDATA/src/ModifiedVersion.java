import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

public class ModifiedVersion extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JTextField ageField;
    private JButton saveButton;
    private JLabel label = new JLabel("Information");

    // Constructor that sets up the user interface
    public ModifiedVersion() {
        // Set the title of the window
        setTitle("User Data");
        // Set the size of the window
        setSize(400, 200);
        // Specify that the program should exit when the window is closed
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        // Set the layout manager for the window
        setLayout(new FlowLayout());

        // Create text fields for username, password, and age
        usernameField = new JTextField(20);
        passwordField = new JPasswordField(20);
        ageField = new JTextField(3);
        // Create the save button
        saveButton = new JButton("Save");

        // Add labels and fields to the window
        add(new JLabel("Username:"));
        add(usernameField);
        add(new JLabel("Password:"));
        add(passwordField);
        add(new JLabel("Age:"));
        add(ageField);
        add(saveButton);
        add(label);

        // Add an action listener to the save button
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Call the saveUserData method when the save button is clicked
                saveUserData();
            }
        });

        // Load the user data from the file
        loadUserData();
    }

    // Method to save the user data to a file
    private void saveUserData() {
        // Get the values entered by the user
        String username = usernameField.getText();
        char[] password = passwordField.getPassword();
        String age = ageField.getText();

        // Write the values to a file
        try (FileWriter writer = new FileWriter("userdata.txt")) {
            // Concatenate the values into a single string, separated by commas
            writer.write(username + "," + new String(password) + "," + age);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method to load the user data from the file
    private void loadUserData() {
        // Check if the file exists
        File file = new File("userdata.txt");
        if (file.exists()) {
            // Read the contents of the file
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                // Split the contents of the file into an array
                String[] data = reader.readLine().split(",");
                // Set the values in the text fields

                label.setText("Previous Username: " + data[0] +
                        ". Password: "+data[1] +
                        ". Age: " + data[2]);

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        // Create a new UserDataFrame object
        ModifiedVersion frame = new ModifiedVersion();
        // Make the window visible
        frame.setVisible(true);
    }
}


