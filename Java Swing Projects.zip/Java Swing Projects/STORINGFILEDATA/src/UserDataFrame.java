import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

/*Explanation:

In the constructor of the UserDataFrame class, a JTextField and a JButton are created and added to the frame.

The saveUsername method is called when the "Save" button is clicked. It writes the contents of the text field
to a file named "username.txt".

The loadUsername method is called when the program starts. It reads the contents of the file "username.txt"
and sets it to the text field if the file exists.*/

// Class that extends JFrame to create the GUI
public class UserDataFrame extends JFrame {
    private JTextField usernameField;// Text field for the user to enter their username
    private JButton saveButton;// Button for the user to click to save their username

    // Constructor for the UserDataFrame class
    public UserDataFrame() {

        setTitle("User Data");  // Set the title of the frame
        setSize(400, 200);  // Set the size of the frame
        setDefaultCloseOperation(EXIT_ON_CLOSE);    // Specify the default close operation
        setLayout(new FlowLayout());    // Set the layout manager for the frame

        usernameField = new JTextField(20);     // Initialize the text field
        saveButton = new JButton("Save");   // Initialize the save button

        add(new JLabel("Username:"));   // Add a label and the text field to the frame
        add(usernameField);

        add(saveButton);    // Add the save button to the frame

        // Add an action listener to the save button
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveUsername(); // Call the saveUsername method when the button is clicked
            }
        });


        loadUsername(); // Load the username from the file, if it exists
    }

    // Method to save the username to a file
    private void saveUsername() {

        String username = usernameField.getText();  // Get the text from the text field

        try (FileWriter writer = new FileWriter("username.txt")) {// Write the text to the file "username.txt"
            writer.write(username);
        } catch (IOException e) {
            e.printStackTrace();    // Print an error message if the file cannot be written
        }
    }

    // Method to load the username from a file
    private void loadUsername() {
        // Check if the file "username.txt" exists
        File file = new File("username.txt");
        if (file.exists()) {

            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {    // Read the contents of the file

                usernameField.setText(reader.readLine());// Set the contents of the file to the text field
            } catch (IOException e) {

                e.printStackTrace();// Print an error message if the file cannot be read
            }
        }
    }

    // Main method to launch the program
    public static void main(String[] args) {

        ModifiedVersion frame = new ModifiedVersion();// Create a new instance of the UserDataFrame class

        frame.setVisible(true);// Make the frame visible
    }
}

