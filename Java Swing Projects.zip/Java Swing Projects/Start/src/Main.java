import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {

        // JFrame is a GUI window to add components to

        JFrame frame = new JFrame();    // Creates a frame
        ImageIcon image = new ImageIcon("ShrekLogo.png");   // Creates image icon

        frame.setSize(420, 420);    // Sets size in int
        frame.setTitle("JFrame title goes here");   // Sets title
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);   // Exit option
        frame.setResizable(false);  // Prevent resize and fullscreen
        frame.setIconImage(image.getImage());   // Change icon of frame
        frame.getContentPane().setBackground(Color.BLACK);  // Changes background color
        frame.getContentPane().setBackground(new Color(0, 0, 0)); // Changes background color RGB


        frame.setVisible(true);     // Makes frame visible

}}