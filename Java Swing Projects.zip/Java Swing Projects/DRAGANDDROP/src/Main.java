public class Main {

    public static void main(String[] args) {

        MyFrame myFrame = new MyFrame();

        /*


        I DONT KNOW HOW TO DO THIS!!!!11!!1 ITS UP TO YOU FUTURE BRAEDEN!!! FIGURE THIS SHIT OUT
        GOODLUCK!!!! ONG I WAS TRYING TO FOLLOW ALONG WITH THE VIDEO, BUT THE CLICKLINSTENER CLASS
        DOES NOT FCKING WORK AND IDK WHY. IM NOT GOING TO ASK CHATGPT BCUS THEN I THINK ILL HAVE TO REDO
        THE ENTIRE DAMN SETUP. ANYWAYS, GOOD LUCK BUDDY!!


         */

    }

}
