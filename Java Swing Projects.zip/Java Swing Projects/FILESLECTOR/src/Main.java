import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.io.File;

public class Main {

    /* JFileChooser
    Allows a user to choose a file (Helpful for opening or saving files)
     */

    public static void main(String[] args) {

        // - - - - - - - - - - Setup - - - - - - - - - - \\

        JFrame frame = new JFrame("File Selector");

        JButton button = new JButton("Select File");

        JFileChooser chooser = new JFileChooser();


        // - - - - - - - - - - Buttons - - - - - - - - - - \\

        button.addActionListener(e -> {

            chooser.setCurrentDirectory(new File("."));     // Sets the default directory to this project folder. For other directories,copy and paste the path in the ""

            int response = chooser.showOpenDialog(null);   // Select file to open
            // int response = chooser.showSaveDialog(null);    // Selects file to save

            if (response == JFileChooser.APPROVE_OPTION) {
                File file = new File(chooser.getSelectedFile().getAbsolutePath());  // Gets the path of your file
                System.out.println(file);   // Prints that path to a file
            }

        });


        // - - - - - - - - - - Frames - - - - - - - - - - \\

        frame.add(button);

        frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());
        frame.pack();

        frame.setVisible(true);





    }


}
