import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;

public class Main {

    public static void main(String[] args) {

        JFrame frame = new JFrame();
        JLabel label = new JLabel();    // creates label
        ImageIcon image = new ImageIcon("ShrekLogo.png");
        Border border = BorderFactory.createLineBorder(Color.GREEN, 3);

        label.setText("You got Shreked");    // Set text of label
        label.setIcon(image);   // Sets the label icon to the image
        label.setHorizontalTextPosition(JLabel.CENTER);     // set text LEFT, CENTER, RIGHT of image icon
        label.setVerticalTextPosition(JLabel.TOP); // set text TOP, CENTER, BOTTOM of image icon
        label.setForeground(Color.GREEN);    // Sets color of the text
        label.setFont(new Font("MV Boli", Font.PLAIN,20));  // Set font of text
        label.setIconTextGap(10);  // Sets gap of the text to the image
        label.setBackground(Color.BLACK);   // Set background color
        label.setOpaque(true);  // Allows background to bet set
        label.setBorder(border); // Sets the color of the border
        label.setVerticalAlignment(JLabel.CENTER); // Sets the alignment of the image and text in the frame
        label.setHorizontalAlignment(JLabel.CENTER); // Sets the alignment horizontally ^
        //label.setBounds(100, 100, 250, 250); // Sets the label bounds

        // frame.setSize(500,500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(label);   // adds label
        //frame.setLayout(null);    // allows the frame layout to be separate from the label layout
        frame.pack();   // resize the size of the frame to adjust to the label. this must be last


        frame.setVisible(true);

    }
}
