import javax.swing.*;
import java.awt.*;

public class Main {

    /* JCheckBox
    A GUI component that can be selected or deselected
     */

    public static void main(String[] args) {

        // - - - - - - - - - - Setup - - - - - - - - - - \\

        JFrame frame = new JFrame();

        JCheckBox checkBox = new JCheckBox();

        JButton button = new JButton();

        ImageIcon xIcon = new ImageIcon("x.png");
        ImageIcon checkIcon = new ImageIcon("check.png");

        // - - - - - - - - - - Checkboxes - - - - - - - - - - \\

        checkBox.setText("I'm not a robot");    // Sets the text to the right of the checkbox
        checkBox.setFocusable(false);   // Removes annoying border around text
        checkBox.setFont(new Font("Consolas", Font.PLAIN, 25)); // changes font
        checkBox.setIcon(xIcon);    // Unselected Icon
        checkBox.setSelectedIcon(checkIcon);    // Selected Icon

        // - - - - - - - - - - Buttons - - - - - - - - - - \\

        button.setText("Submit");
        button.addActionListener(e -> {
            if (e.getSource() == button) {
                System.out.println(checkBox.isSelected());
            }
        });

        // - - - - - - - - - - Frames - - - - - - - - - - \\

        frame.add(checkBox);
        frame.add(button);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());
        frame.pack();
        frame.setVisible(true);



    }

}
