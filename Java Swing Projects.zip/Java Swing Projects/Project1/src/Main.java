import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.*;

public class Main extends JFrame {

    private JTextField inputField;
    private JList<String> outputList;
    private JButton addButton;
    private JButton updateButton;
    private JButton deleteButton;
    private JButton editButton;
    private List<String> inputs = new ArrayList<>();
    private DefaultListModel<String> model;

    public static void main(String[] args) {
        Main frame = new Main();
        frame.setVisible(true);
    }

    public Main() {
        setTitle("Places I Want to Visit");
        setSize(800, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLayout(new GridBagLayout());

        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 0;
        c.gridy = 0;

        inputField = new JTextField();
        inputField.setText("Insert Place");
        add(inputField, c);

        addButton = new JButton("Add");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String input = inputField.getText();
                inputs.add(input);
                model.addElement(input);
            }
        });
        c.gridx = 1;
        add(addButton, c);

        updateButton = new JButton("Update");
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateScene();
            }
        });
        c.gridx = 2;
        add(updateButton, c);

        model = new DefaultListModel<>();
        outputList = new JList<>(model);
        c.fill = GridBagConstraints.BOTH;
        c.gridx = 0;
        c.gridy = 1;
        c.gridwidth = 3;
        c.gridheight = 2;
        c.weighty = 1;
        add(new JScrollPane(outputList), c);
        deleteButton = new JButton("Delete");
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedIndex = outputList.getSelectedIndex();
                if (selectedIndex != -1) {
                    inputs.remove(selectedIndex);
                    model.remove(selectedIndex);
                }
            }
        });
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 0;
        c.gridy = 3;
        c.gridwidth = 1;
        c.gridheight = 1;
        c.weighty = 0;
        add(deleteButton, c);

        editButton = new JButton("Edit");
        editButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedIndex = outputList.getSelectedIndex();
                if (selectedIndex != -1) {
                    String newInput = JOptionPane.showInputDialog(Main.this, "Edit Place", "Edit Place", JOptionPane.PLAIN_MESSAGE);
                    inputs.set(selectedIndex, newInput);
                    model.set(selectedIndex, newInput);
                }
            }
        });
        c.gridx = 1;
        add(editButton, c);

        readFile();
    }

    private void updateScene() {
        try (FileWriter writer = new FileWriter(new File("C:\\Users\\Braed\\Desktop\\New folder\\places.txt"))) {
            for (String input : inputs) {
                writer.write(input + System.lineSeparator());
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(Main.this, "Could not save data to file", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void readFile() {
        try (FileReader reader = new FileReader(new File("C:\\Users\\Braed\\Desktop\\New folder\\places.txt"))) {
            int c;
            StringBuilder sb = new StringBuilder();
            while ((c = reader.read()) != -1) {
                char character = (char) c;
                if (character == '\n') {
                    inputs.add(sb.toString());
                    model.addElement(sb.toString());
                    sb.setLength(0);
                } else {
                    sb.append(character);
                }
            }
        } catch (FileNotFoundException e) {
            JOptionPane.showMessageDialog(Main.this, "File not found", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(Main.this, "Could not read data from file", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
