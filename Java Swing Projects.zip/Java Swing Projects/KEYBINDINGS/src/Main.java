public class Main {

    /* Key Bindings
    Bind an Action to a Keystroke
    doesnt reqiure you to click a component to give it focus
    all swing components use Key Bindings
    Increased felcibility compared to KeyListeners
    Can assign keystrokes to individual Swing components
    more difficult to utilize and set up though :(
     */

    public static void main(String[] args) {

        Game game = new Game();



    }

}
