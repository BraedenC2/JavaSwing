import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class Main {

    public static void main(String[] args) {

        /* GridLayout:
        Places components in a grid of cells. Each component takes all the available space
        within its cell, and each cell is the same size.
         */

        // - - - - - - - - - - Setup - - - - - - - - - - \\

        JFrame frame = new JFrame();

        JButton button1 = new JButton("1");
        JButton button2 = new JButton("2");
        JButton button3 = new JButton("3");
        JButton button4 = new JButton("4");
        JButton button5 = new JButton("5");

        // - - - - - - - - - - Buttons - - - - - - - - - \\




        // - - - - - - - - - - Frames - - - - - - - - - - \\

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLayout(new GridLayout(3,3,0,0));

        frame.add(button1);
        frame.add(button2);
        frame.add(button3);
        frame.add(button4);
        frame.add(button5);

        frame.add(new JButton("6"));
        frame.add(new JButton("7"));
        frame.add(new JButton("8"));
        frame.add(new JButton("9"));

        frame.setVisible(true);

    }

}
