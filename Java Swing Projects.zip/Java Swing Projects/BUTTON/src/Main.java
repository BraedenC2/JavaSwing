import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main {

    public static void main(String[] args) {

        // JButton allows us to perform actions when clicked

        JFrame frame = new JFrame();
        JButton button = new JButton();
        ImageIcon icon = new ImageIcon("ShrekLogo.png");
        JLabel label = new JLabel("HII");

        label.setBounds(JLabel.CENTER, JLabel.BOTTOM, 500, 500);
        label.setVisible(false);


        button.setBounds(100, 100, 400,400);
        button.addActionListener(e -> {
            if (e.getSource() == button) {
                System.out.println("hi");
                button.setEnabled(false);
                label.setVisible(true);
            }
        });
        button.setText("Press me :)");
        button.setFocusable(false);     // Gets rid of annoying box
        button.setIcon(icon);
        button.setHorizontalTextPosition(JButton.CENTER);
        button.setVerticalTextPosition(JButton.BOTTOM);
        button.setFont(new Font("Arial", Font.BOLD, 25));
        button.setIconTextGap(-5);
        button.setForeground(Color.RED);
        button.setBackground(Color.GREEN);
        button.setBorder(BorderFactory.createEtchedBorder());
        button.setEnabled(true);





        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        frame.setSize(500,500);
        frame.add(button);
        frame.add(label);

        frame.setVisible(true);



    }

}
