import javax.swing.*;

public class Main {

    /* JOptionPane:
    A dialog box that prompts users for a value or informs them of something.
     */

    public static void main(String[] args) {

        // - - - - - - - - - - Setup - - - - - - - - - - \\

        // Our ICON here will replace the original in our line 43 Dialog
        ImageIcon overrideIcon = new ImageIcon("ShrekLogo.png");
        // Our responses here will be the new options they can click on in line 43 dialog
        String[] responses = {"No, you're awesome!", "thank you", "*blush*", "GAY"};

        JOptionPane.showMessageDialog(null, "This is some useless info", "title", JOptionPane.PLAIN_MESSAGE);
        JOptionPane.showMessageDialog(null, "This is some useless info", "title", JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(null, "This is some useless info", "title", JOptionPane.QUESTION_MESSAGE);
        JOptionPane.showMessageDialog(null, "This is some useless info", "title", JOptionPane.WARNING_MESSAGE);
        JOptionPane.showMessageDialog(null, "This is some useless info", "title", JOptionPane.ERROR_MESSAGE);

        // The differences between these are the icon boxes that show up next to the text ^

        JOptionPane.showConfirmDialog(null, "HELLO :)", "Tit L", JOptionPane.YES_NO_CANCEL_OPTION);

        // This and others like it, allows us options or buttons to click. ^^
        // To understand how to make the buttons do something:

        System.out.println(JOptionPane.showConfirmDialog(null, "HELLO :)", "Tit L", JOptionPane.YES_NO_CANCEL_OPTION));

        // YES returns 0, NO returns 1, CANCEL returns 2, and exiting returns -1.
        // So you can assign this to a variable, and have the variable do something if it equals
        // a certain number that this outputs.

        // This asks the user their name, and allows them to input a String in a box
        // The String name stores their response
        String name= JOptionPane.showInputDialog("What is your name?");
        System.out.println("Hello " + name);

        // Finally, from this lesson, this combines ALL the ones we've currently used
        JOptionPane.showOptionDialog(null, "Message", "title", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, overrideIcon, responses, 0);


        // - - - - - - - - - - XXX - - - - - - - - - - \\

    }

}
