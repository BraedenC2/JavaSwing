import javax.swing.*;
import java.awt.*;

public class Main {

    /* JColorChooser
    A GUI mechanism that lets a user choose a color
     */

    public static void main(String[] args) {

        JFrame frame = new JFrame();

        JButton button = new JButton("Pick a color");

        JLabel label = new JLabel();

        label.setBackground(Color.WHITE);
        label.setOpaque(true);
        label.setText("This is some text");
        label.setFont(new Font("Arial", Font.BOLD, 90));

        button.addActionListener(e -> {
            JColorChooser colorChooser = new JColorChooser();

            Color color = JColorChooser.showDialog(null, "Pick a color", Color.BLACK);

            // label.setForeground(color);
            label.setBackground(color);


        });





        frame.add(button);
        frame.add(label);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());
        frame.pack();

        frame.setVisible(true);


    }

}
