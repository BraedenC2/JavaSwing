import javax.swing.*;
import java.awt.*;

public class MyFrame extends JFrame {

    MyFrame() {

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500,500);
        setLocationRelativeTo(null);
        setVisible(true);

    }

    public void paint(Graphics g) {



    }




}
