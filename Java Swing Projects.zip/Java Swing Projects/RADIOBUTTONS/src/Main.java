import javax.swing.*;
import java.awt.*;

public class Main {

    /* JRadioButton
    One or more buttons in a grouping in which only 1 may
    be selected per group.
     */

    public static void main(String[] args) {

        // - - - - - - - - - - Setup - - - - - - - - - - \\

        JFrame frame = new JFrame();

        JRadioButton pizzaButton = new JRadioButton("Pizza");
        JRadioButton hamburgerButton = new JRadioButton("Hamburger");
        JRadioButton hotdogButton = new JRadioButton("Hotdog");

        ImageIcon pizzaImage = new ImageIcon("Pizza.png");
        ImageIcon hamburgerImage = new ImageIcon("hamburger.jpg");
        ImageIcon hotdogImage = new ImageIcon("hot dog.jpg");

        ButtonGroup group = new ButtonGroup();  // Allows us to select ONLY 1 button when we assign them to it

        // - - - - - - - - - - ButtonGroups - - - - - - - - - - \\

        group.add(pizzaButton);
        group.add(hamburgerButton);
        group.add(hotdogButton);

        // - - - - - - - - - - Radio Buttons - - - - - - - - - - \\

        pizzaButton.addActionListener(e -> {
            if (e.getSource()==pizzaButton){
                System.out.println("You ordered Pizza!");
                pizzaButton.setEnabled(false);
                hamburgerButton.setEnabled(false);
                hotdogButton.setEnabled(false);
            }
        });
        pizzaButton.setIcon(pizzaImage);

        hamburgerButton.addActionListener(e -> {
            if (e.getSource()==hamburgerButton){
                System.out.println("You ordered Hamburger!");
                pizzaButton.setEnabled(false);
                hamburgerButton.setEnabled(false);
                hotdogButton.setEnabled(false);
            }
        });
        hamburgerButton.setIcon(hamburgerImage);

        hotdogButton.addActionListener(e -> {
            if (e.getSource()==hotdogButton){
                System.out.println("You ordered a Hotdog!");
                pizzaButton.setEnabled(false);
                hamburgerButton.setEnabled(false);
                hotdogButton.setEnabled(false);
            }
        });
        hotdogButton.setIcon(hotdogImage);

        // - - - - - - - - - - Frames - - - - - - - - - - \\

        frame.add(pizzaButton);
        frame.add(hamburgerButton);
        frame.add(hotdogButton);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());
        frame.pack();
        frame.setVisible(true);
    }

}
