import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;

public class Main {

    public static void main(String[] args) {

        // - - - - - - - - - - Setup - - - - - - - - - - \\

        JFrame frame = new JFrame();

        JMenuBar menuBar = new JMenuBar();  // This is how you create a MenuBar

        JMenu fileMenu = new JMenu("File");     // This is how you create menu options for your MenuBar
        JMenu editMenu = new JMenu("Edit");
        JMenu helpMenu = new JMenu("Help");

        JMenuItem loadItem = new JMenuItem("Load");     // This is how you create menu items for your menu options
        JMenuItem saveItem = new JMenuItem("Save");
        JMenuItem exitItem = new JMenuItem("Exit");

        ImageIcon loadIcon = new ImageIcon("LoadIcon.jpg");
        ImageIcon saveIcon = new ImageIcon("SaveIcon.jpg");
        ImageIcon exitIcon = new ImageIcon("ExitIcon.jpg");

        // - - - - - - - - - - Menu Bars - - - - - - - - - - \\

        menuBar.add(fileMenu);      // This is how you add your menu options to your menu bar
        menuBar.add(editMenu);
        menuBar.add(helpMenu);

        // - - - - - - - - - - Menu Options - - - - - - - - - - \\

        fileMenu.add(loadItem);     // Thi is how you add your menu items to your menu options
        fileMenu.add(saveItem);
        fileMenu.add(exitItem);

        fileMenu.setMnemonic(KeyEvent.VK_F);    // This is how you create shortcut keys for menu options. You need to hold alt + F to use fileMenu
        editMenu.setMnemonic(KeyEvent.VK_E);    // alt + E for edit, etc etc etc
        helpMenu.setMnemonic(KeyEvent.VK_H);

        // - - - - - - - - - - Menu Items - - - - - - - - - - \\

        // This is how you give your menu item an action

        loadItem.addActionListener(e -> {
            System.out.println("Loading File");
        });

        saveItem.addActionListener(e -> {
            System.out.println("Saving File");
        });

        exitItem.addActionListener(e -> {
            System.out.println("Exiting");
            try {
                Thread.sleep(1000);
            } catch (InterruptedException ignored) {}
            System.exit(0);
        });

        loadItem.setMnemonic(KeyEvent.VK_L);    // This is how you set a key as a shortcut to our menu items. this case, l will activate load
        saveItem.setMnemonic(KeyEvent.VK_S);
        exitItem.setMnemonic(KeyEvent.VK_E);

        loadItem.setIcon(loadIcon);     // This is how you set icons to your Menu Items
        saveItem.setIcon(saveIcon);
        exitItem.setIcon(exitIcon);

        // - - - - - - - - - - Frames - - - - - - - - - - \\

        frame.setJMenuBar(menuBar);     // This is how you add (in this case, set) our MenuBar

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLayout(new FlowLayout());

        frame.setVisible(true);


    }

}
