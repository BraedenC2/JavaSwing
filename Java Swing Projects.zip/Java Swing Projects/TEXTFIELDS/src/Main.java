import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class Main {

    /* JTextField
    A GUI text-box component that can be used to add, set, or get text
     */

    public static void main(String[] args) {

        // - - - - - - - - - - Setup - - - - - - - - - - \\

        JFrame frame = new JFrame();

        JTextField textField = new JTextField();

        JButton button = new JButton("Submit");

        // - - - - - - - - - - TextFields - - - - - - - - - - \\

        textField.setPreferredSize(new Dimension(250, 40));
        textField.setFont(new Font("Consolas", Font.PLAIN, 35));    // Changes the text font IN the text field
        textField.setForeground(Color.RED);   // Changes the color of the text IN the text box
        textField.setBackground(Color.black);   // Changes the color of the background in the text box
        textField.setCaretColor(Color.RED);     // Changes the blinking mouse things color in the text box
        textField.setText("First Name");    // Sets the text in the text box
        // textField.setEnabled(false);    // Prevents the text ^ from being edited

        // - - - - - - - - - - Buttons - - - - - - - - - - \\

        button.addActionListener(e -> {
            if (e.getSource() == button) {
                System.out.println("Welcome " + textField.getText());
                button.setEnabled(false);
                textField.setEnabled(false);
            }
        });



        // - - - - - - - - - - Frames - - - - - - - - - - \\

        frame.add(textField);
        frame.add(button);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());
        frame.pack();   // Size will adjust to components
        frame.setVisible(true);

    }

}
