import javax.swing.*;
import java.awt.*;

public class Main {

    /* Progress Bar
    Visual aid to help user know that an operation is progressing
     */

    public static void main(String[] args) {

        // - - - - - - - - - - Setup - - - - - - - - - - \\

        JFrame frame = new JFrame("Progress bar");

        JProgressBar bar = new JProgressBar(0, 100);    // This is how you adjust the size of the progress bar (in terms of progress)

        // - - - - - - - - - - Progress Bars - - - - - - - - - - \\

        bar.setValue(0);    // This is how you set the starting value
        bar.setBounds(0, 0, 500, 50);   // set size to the frame
        bar.setStringPainted(true);     // Adds a percentage to our progress bar
        bar.setFont(new Font("MV Boli", Font.BOLD, 20));    // Change the font
        bar.setForeground(Color.RED);   // Changes the fill color of the progress bar
        bar.setBackground(Color.BLACK);     // Changes the background of the bar

        // - - - - - - - - - - Frames - - - - - - - - - - \\

        frame.add(bar);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLayout(null);

        frame.setVisible(true);


        // - - - - - - - - - - Progress Bar running - - - - - - - - - - \\

        // THIS MUST BE AT THE END!!
        // This is a loop that update the progress bar
        for (int i = 0; i <= 100; i++) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException ignored) {}
            bar.setValue(i);
        }

        bar.setString("Done");      // This sets what is shown once it reaches 100%

        try {
            Thread.sleep(1000);
        } catch (InterruptedException ignored) {}

        for (int i = 100; i >= 0; i--) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException ignored) {}
            bar.setValue(i);
        }
        bar.setString("restarted");

    }
}
