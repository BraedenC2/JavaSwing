import javax.swing.*;
import java.awt.*;

public class Main {

    /* JSlider
    Lets user enter a value by using an adjustable sliding knob on a track
     */

    public static void main(String[] args) {

        // - - - - - - - - - - Setup - - - - - - - - - - \\
        JFrame frame = new JFrame("Slider Demo");

        JPanel panel = new JPanel();

        JLabel label = new JLabel();

        JSlider slider = new JSlider(-30, 100, 50);
        // This is how you make a slider. the numbers are the min and max on the slider, and the third number is the starting point

        //  - - - - - - - - - - Panels - - - - - - - - - - \\

        panel.add(slider);
        panel.add(label);

        //  - - - - - - - - - - Sliders - - - - - - - - - - \\

        slider.setPreferredSize(new Dimension(400, 200));

        slider.setPaintTicks(true);     // Sets the ticks to true, so you can create them
        slider.setMinorTickSpacing(10);     // Creates the minor ticks

        slider.setPaintTrack(true);     // sets the ticks to true, so you can create them (major ones)
        slider.setMajorTickSpacing(25); // Creates the major ticks

        slider.setPaintLabels(true);    // Shows the major tick numbers

        slider.setFont(new Font("MV Boli", Font.PLAIN, 15));

        slider.setOrientation(SwingConstants.VERTICAL);     // Makes our slider vertical
        // slider.setOrientation(SwingConstants.HORIZONTAL);   // Makes our slider horizontal

        slider.addChangeListener(e -> {     // This is like ActionListener, but for sliders.
            label.setText("°C = " + slider.getValue());     // The getValue() allows us to get the number our slider is on
        });

        //  - - - - - - - - - - Labels - - - - - - - - - - \\

        label.setText("°C = " + slider.getValue());     // The getValue() allows us to get the number our slider is on
        label.setFont(new Font("Arial", Font.BOLD, 20));



        //  - - - - - - - - - - Frames - - - - - - - - - - \\

        frame.add(panel);


        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(420,420);

        frame.setVisible(true);




    }


}
